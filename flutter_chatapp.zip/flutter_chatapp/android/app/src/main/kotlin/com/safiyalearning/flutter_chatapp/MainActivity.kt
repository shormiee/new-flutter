package com.safiyalearning.flutter_chatapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
