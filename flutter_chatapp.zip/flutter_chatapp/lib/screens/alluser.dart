import 'package:flutter/material.dart';

class AllUser extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
       appBar: AppBar(
         title: Text('welcome to all users screen'),
       ),
    );
  }
}
